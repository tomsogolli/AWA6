import express, {Express, Request, Response} from "express"

const app: Express = express()
const port: number = 3000

type vehicle = {
    model: string
    color: string
    year: number
    power: number
    bodyType?: string
    wheelCount?: number
    draft?: number
}

let vehicles: vehicle[] = []


app.get("/hello", (req: Request, res: Response) => {
    res.send("Hello world")
})

app.post("/vehicle/add", (req: Request, res: Response) =>{
    console.log(req.body)
    var vh: vehicle = JSON.parse(req.body)
    vehicles.push(vh)
    res.status(201).send("Vehicle added")
})

app.get("/vehicles", (req: Request, res: Response) => {
    res.send(vehicles)
})

app.listen(port, () => {
    console.log("Server running!")
})

